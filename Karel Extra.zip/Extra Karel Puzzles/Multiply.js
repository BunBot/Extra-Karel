function start(){
	var num1 = 0;
	var num2 = 0;
	move();
	while(ballsPresent()){
	    takeBall();
	    var num1 = num1 + 1;
	}
	move();
	while(ballsPresent()){
	    takeBall();
	    var num2 = num2 + 1;
	}
	for (var i = 0; i < (num1 * num2); i++){
	    putBall();
	}
	turnAround();
	move();
	turnAround();
}
