function start(){
	var x = 0;
	move();
	while(ballsPresent()){
	    takeBall();
	    var x = x + 1;
	}
	for (var i = 0; i < x; i++){
	    putBall();
	}
	move();
	for (var i = 0; i < x; i++){
	    putBall();
	}
	turnAround();
	move();
	move();
	turnAround();
}
