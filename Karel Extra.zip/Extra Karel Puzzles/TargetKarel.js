function start(){
	while(noBallsPresent()){
	    while(frontIsClear()){
	        while(noBallsPresent()){
	            move();  
	            if(frontIsBlocked()){
	                break;
	            }
	        }
	        break;
	    }
	    if(facingEast()){
	        if(frontIsBlocked()){
    	        turnLeft();
    	        move();
    	        turnLeft();
	        }
	    }
	    if(facingWest()){
	        if(frontIsBlocked()){
    	        turnRight();
    	        move();
    	        turnRight();
	        }
	    }
	}
	//Finds the spot
	
	
	right();
	left();
	top();
	bottom();
	while (notFacingEast()){
	    turnLeft();
	}
}

function right(){
    var rightX = 0;
    while(notFacingSouth()){
        turnLeft();
    }
    while(frontIsClear()){
        move();
        putBall();
        rightX += 1;
    }
    if(noBallsPresent()){
        putBall();
    }
    turnAround();
    for (var i = 0; i < rightX; i++){
        move();
    }
    turnRight();
}

function left(){
    var leftX = 0;
    while(notFacingNorth()){
        turnLeft();
    }
    while(frontIsClear()){
        move();
        putBall();
        leftX += 1;
    }
    if(noBallsPresent()){
        putBall();
    }
    turnAround();
    for (var i = 0; i < leftX; i++){
        move();
    }
    turnRight();
}

function top(){
    var topX = 0;
    while(notFacingEast()){
        turnLeft();
    }
    while(frontIsClear()){
        move();
        putBall();
        topX += 1;
    }
    if(noBallsPresent()){
        putBall();
    }
    turnAround();
    for (var i = 0; i < topX; i++){
        move();
    }
    turnRight();
}

function bottom(){
    var bottomX = 0;
    while(notFacingWest()){
        turnLeft();
    }
    while(frontIsClear()){
        move();
        putBall();
        bottomX += 1;
    }
    if(noBallsPresent()){
        putBall();
    }
    turnAround();
    for (var i = 0; i < bottomX; i++){
        move();
    }
    turnRight();
}
