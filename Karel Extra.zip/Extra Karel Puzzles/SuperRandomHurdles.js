function start(){
	turnLeft();
	while(frontIsClear()){
	    move();
	}
	turnRight();
	while(frontIsClear()){
	    move();
	}
	turnRight();
	while(frontIsClear()){
	    move();
	}
	turnLeft();
}
