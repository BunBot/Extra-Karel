function start(){
    var x1 = 0;
    var x2 = 0;
    var x3 = 0;
    var x4 = 0;
    var x5 = 0;
    var x6 = 0;
    var x7 = 0;
    while(frontIsClear()){
        move();
        if(ballsPresent()){
            while(ballsPresent()){
                takeBall();
                x1 = x1 + 1;
            }
            turnLeft();
            for(var i = 0; i < x1; i++){
                if(frontIsClear()){
                    putBall();
                    move();
                }else{
                    putBall();
                }
            }
            x1 = 0;
            turnAround();
            while(frontIsClear()){
                move();
            }
            turnLeft();
        }
    }
    turnAround();
    while(frontIsClear()){
        move();
    }
    turnAround();
    turnLeft();
    while(frontIsClear()){
        move();
    }
    turnRight();
    
    //Row Checking Begins
    while(rightIsClear()){
        while(frontIsClear()){
            if(ballsPresent()){
                takeBall();
                x2 = x2 + 1;
            }else{
                if(frontIsClear()){
                    move();
                }
            }
        }
        for (var i = 0; i < x2; i++){
            if(noBallsPresent()){
                putBall();
            }else{
                turnAround();
                move();
                turnAround();
                putBall();
            }
        }
        nextRow();
        x2 = 0;
    }
    
    turnLeft();
    while(frontIsClear()){
        move();
    }
    turnRight();
    while(rightIsClear()){
        while(frontIsClear()){
            if(noBallsPresent()){
                move();
            }else{
                turnLeft();
                takeBall();
                x3 = x3 + 1;
            }
            for (var i = 0; i < x3; i++){
                putBall();
            }
            turnLeft();
            while(frontIsClear()){
                move();
            }
        }
        break;
    }
    turnLeft();
    move();
    turnAround();
    //Check for Duplicates***
    while(frontIsClear()){
        move();
        if(ballsPresent()){
            if(frontIsClear()){
                move();
            }
            if(ballsPresent()){
                turnAround();
                move();
                takeBall();
                turnAround();
                move();
                putBall();
                turnAround();
                while(frontIsClear()){
                    move();
                }
                turnAround();
                break;
            }
        }
    }
    
    //Pre-Condition is karel in top left corner
    while(rightIsClear()){
        rowCheck();
        nextRow();
    }
    
    
}


function nextRow(){
    turnAround();
    while(frontIsClear()){
        move();
    }
    turnLeft();
    if(frontIsClear()){
        move();
    }
    turnLeft();
}

function rowCheck(){
    var ballNum = 0;
    while(frontIsClear()){
        if(ballsPresent()){
            turnRight();
            takeBall();
            ballNum = ballNum + 1;
            if(noBallsPresent()){
                while(frontIsClear()){
                    move();
                    ballNum = ballNum + 1;
                    takeBall();
                }
                for (var i = 0; i < ballNum; i++){
                    putBall();
                }
                turnAround();
                for(var i = 0; i < ballNum; i++){
                    if(frontIsClear()){
                        move();
                    }
                }
                turnRight();
                ballNum = 0;
            }else{
                
            }
        }
        move();
    }
    if(ballsPresent()){
        turnRight();
        while(frontIsClear()){
            while(ballsPresent()){
                takeBall();
                ballNum = ballNum + 1;
            }
            move();
        }
        for (var i = 0; i < ballNum; i++){
            putBall();
        }
        turnAround();
        for(var i = 0; i < ballNum; i++){
            if(frontIsClear()){
                move();
            }
        }
        turnRight();
        ballNum = 0;
    }
}


/*
Karel goes along the screen picking up the balls one at a time, 
until all are gone
everytime a place is empty it will add the number to the list
Then What? NO!


Turn the numbers into columns of the numbers height
then have Karel run along from the top adding them in order then
like the game 2048

At max height: if highest ball is equal to the one beneath it, execute emeregncyMap
num 5 specifically.

*/


