function start(){
	var num1 = 0;
	var num2 = 0;
	move();
	while(ballsPresent()){
	    takeBall();
	    num1 = num1 + 1;
	}
	for(var i = 0; i < num1; i++){
	    putBall();
	}
	move();
	
	
	while(ballsPresent()){
	    takeBall();
	    num2 = num2 + 1;
	}
	for (var i = 0; i < num2; i++){
	    putBall();
	}
	
	
	turnAround();
	move();
	move();
	turnRight();
	move();
	turnRight();
	move();
	for(var i = 0; i < num1; i++){
	    putBall();
	}
	move();
	for(var i = 0; i < num2; i++){
	    putBall();
	}
	if(noBallsPresent()){
	    turnAround();
	    move();
	    while(ballsPresent()){
	        takeBall();
	    }
	    turnAround();
	}else{
    	turnAround();
    	move();
    	turnAround();
    	move2Biggest();
	}
}

function move2Biggest(){
    while(ballsPresent()){
        takeBall();
        if(ballsPresent()){
            move();
        }
        if(ballsPresent()){
            takeBall();
            turnAround();
            move();
            turnAround();
        }else{
            turnAround();
            move();
            turnAround();
        }
    }
    move();
    move();
    if(ballsPresent()){
        while(ballsPresent()){
            takeBall();
        }
    }else{
        turnAround();
        move();
        turnAround();
    }
}
