function start(){
	var fib = [2,3,5,8,13,21,34,55];
	var x = 0;
	if(ballsPresent()){
        move();
        move();
    }
	while(frontIsClear()){
	    for(var i = 0; i < fib[x]; i++){
	        putBall();
	    }
	    x = x + 1;
	    if(frontIsClear()){
	        move();
	    }
	}
	if(noBallsPresent()){
	    for(var i = 0; i < fib[x]; i++){
	        putBall();
	    }
	}
	turnAround();
	while(frontIsClear()){
	    move();
	}
	turnAround();
}
