function start(){
    var x = 0;
	while(frontIsClear()){
	    move();
	    x = x + 1;
	}
	turnAround();
	for (var i = 0; i < x/2; i++){
	    move();
	}
	putBall();
	turnAround();
}
