function start(){
	moveFive();
	putBall();
	moveFive();
	turnLeft();
	move();
	turnLeft();
	moveFive();
	putBall();
	moveFive();
	turnRight();
	move();
	turnRight();
	
	firstRow();
	putBall();
	nextRowRight();
	secondRow();
	nextRowLeft();
	move();
	thirdRow();
	nextRowRight();
	move();
	fourthRow();
	putBall();
	turnRight();
	move();
	turnRight();
	move();
	putBall();
	turnLeft();
	move();
	turnRight();
}

function moveFive(){
    for (var i = 0; i < 4; i++){
	    move();
	}
}

function firstRow(){
    for (var i = 0; i < 8; i++){
        putBall();
        move();
    }
}

function secondRow(){
    for (var i = 0; i < 7; i++){
        putBall();
        move();
    }
}

function thirdRow(){
    for (var i = 0; i < 5; i++){
        putBall();
        move();
    }
}

function fourthRow(){
    for (var i = 0; i < 2; i++){
        putBall();
        move();
    }
}

function nextRowRight(){
    turnLeft();
    move();
    turnLeft();
    move();
}

function nextRowLeft(){
    turnRight();
    move();
    turnRight();
    move();
}
