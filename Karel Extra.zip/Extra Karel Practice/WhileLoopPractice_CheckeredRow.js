function start(){
    putBall();
	while(frontIsClear()){
	    move();
	    if(frontIsClear()){
	        move();
	        putBall();
	    }
	}
}
