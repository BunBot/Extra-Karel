function start(){
	bottomLeftX();
	putBall();
	turnRight();
	goDown();
	turnRight();
	bottomRightX();
	putBall();
	turnLeft();
	goDown();
	turnLeft();
	getExtra();
	turnLeft();
}

function bottomLeftX(){
    for (var i = 0; i < 4; i++){
        putBall();
        move();
        turnLeft();
        move();
        turnRight();
    }
}

function bottomRightX(){
    for (var i = 0; i < 4; i++){
        putBall();
        move();
        turnRight();
        move();
        turnLeft();
    }
}

function goDown(){
    for (var i = 0; i < 4; i++){
        move();
    }
}

function getExtra(){
    for (var i = 0; i < 2; i++){
        move();
    }
    turnLeft();
    for (var i = 0; i < 2; i++){
        move();
    }
    takeBall();
    turnLeft();
    for (var i = 0; i < 2; i++){
        move();
    }
    turnLeft();
    for (var i = 0; i < 2; i++){
        move();
    }
}
