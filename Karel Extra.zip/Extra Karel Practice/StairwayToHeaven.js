function start(){
	while(frontIsBlocked()){
	    pattern();
	}
}

function pattern(){
    turnLeft();
    move();
    turnRight();
    move();
}
