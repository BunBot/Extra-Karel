function start(){
    turnLeft();
	kLeft();
	turnLeft();
	move();
	kUpRight();
	putBall();
	downAlot();
	turnRight();
	kDownRight();
	putBall();
	move();
	turnRight();
	returnHome();
	turnLeft();
}

function kLeft(){
    for (var i = 0; i < 9; i++){
        putBall();
        move();
    }
    putBall();
    returnHome();
}

function returnHome(){
    turnLeft();
    turnLeft();
    for (var i = 0; i < 4; i++){
        move();
    }
}

function kDownRight(){
    for (var i = 0; i < 4; i++){
        putBall();
        move();
        turnRight();
        move();
        turnLeft();
    }
}

function kUpRight(){
    for (var i = 0; i < 4; i++){
        putBall();
        move();
        turnLeft();
        move();
        turnRight();
    }
}

function downAlot(){
    turnRight();
    for (var i = 0; i < 9; i++){
        move();
    }
}
