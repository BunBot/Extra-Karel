function start(){
	while(frontIsClear()){
	    putBall();
	    move();
	}
	putBall();
	turnAround();
	while(frontIsClear()){
	    move();
	}
	turnAround();
}

function extra1(){
    move();
}

function extra2(){
    move();
}
