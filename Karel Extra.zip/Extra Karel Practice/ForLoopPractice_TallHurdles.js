function start(){
    turnLeft();
	loopAround();
	turnRight();
	loopAround();
	turnRight();
	loopAround();
	turnLeft();
}

function loopAround(){
    while(frontIsClear()){
        move(); 
    }
}
