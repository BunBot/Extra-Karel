function start(){
    putBall();
	if (frontIsClear()){
	    move();
	    putBall();
	}
	leftClear();
	leftClear();
	turnLeft();
	move();
	turnLeft();
	while(frontIsClear()){
	    move();
	}
	putBall();
	leftClear();
	leftClear();
	leftClear();
	turnLeft();
	move();
}

function leftClear(){
    if(leftIsClear()){
	    turnLeft();
	    move();
	    putBall();
	}
}
