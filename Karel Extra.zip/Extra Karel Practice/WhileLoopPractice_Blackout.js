function start(){
    while (noBallsPresent()){
        while (frontIsClear()){
            putBall();
            move();
        }
        putBall();
        if (facingEast()){
            if (leftIsBlocked()){
                break;
            }
            extraTurnLeft();
            move();
            extraTurnLeft();
        } else{
            if (facingWest()){
                if (rightIsBlocked()){
                    break;
                }
                turnRight();
                move();
                turnRight();
            }
        }
    }
}

function extraTurnLeft(){
    turnLeft();    
}
