function start(){
	while(frontIsClear()){
	    move();
	}
	extraTurnLeft();
	while(frontIsClear()){
        move();
	}
	turnRight();
}

function extraTurnLeft(){
    turnLeft();
}
